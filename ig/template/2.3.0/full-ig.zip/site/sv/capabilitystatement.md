# CapabilityStatement - Inera FHIR Implementation Guide Template v2.3.0

## CapabilityStatement

**Om denna IG definierar formella CapabilityStatements, beskriv dem här och länka till respektive resurs. Ange vilken aktörsroll (t.ex. server/klient) varje CapabilityStatement representerar.**

Fr.o.m. FHIR R5 kan `CapabilityStatement` uttrycka formella konformanskrav per roll via elementet `obligations`, som ett maskinläsbart alternativ eller komplement till de förväntningar som beskrivs under [Roller och ansvar](roles-and-responsibilities.md) under Funktionellt.

